<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>PagePower</name>
    <message>
        <source>Suspend</source>
        <translation>Pauzestand</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Slaapstand</translation>
    </message>
    <message>
        <source>Hybrid Sleep</source>
        <translation>Hybride slaapstand</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <source>Back</source>
        <translation>Terug</translation>
    </message>
</context>
</TS>
